# Description:
WackyBeFree

Unrestricted Portals

A simple mod, for simple Vikings

Support me!

<a href="https://www.buymeacoffee.com/WackyMole" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" height='36' style="height: 36px;" ></a>  [![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/H2H6LL5GA)

Has Server Sync on it, feel free to bash that on/off config.

Cheers!

Use the Built in Vanilla options instead of this mod, but the mod stills works.
