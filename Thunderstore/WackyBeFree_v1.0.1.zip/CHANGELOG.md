| `Version` | `Update Notes`    |
|-----------|-------------------|
| 1.0.0     | - Initial Release |
| 1.0.1     | - Just use the Vanilla Toggle instead of this mod |