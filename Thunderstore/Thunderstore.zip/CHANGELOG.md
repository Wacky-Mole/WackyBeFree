| `Version` | `Update Notes`    |
|-----------|-------------------|
| 1.0.0     | - Initial Release |
| 1.0.1     | - Just use the Vanilla options instead of this mod, but this mod still works |